1) install node in your pc/ laptop
2) run npm install in command line
3) run bower install in command line
4) run node app.js to serve
5) open http://localhost:<port_number> in browser

(or)

1) install python
2) cd client
3) python -m SimpleHTTPServer <port_number>