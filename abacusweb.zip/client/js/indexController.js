;(function() {
    'use strict';

    angular
        .module('abacus')
        .controller('IndexController', IndexController);

    IndexController.$inject = ['$state', '$compile', '$scope'];

    function IndexController($state, $compile, $scope){
        /*var ctrl=this;

        $scope.progressbar = ngProgressFactory.createInstance();
        $scope.progressbar.start();
        $scope.progressbar.complete();*/


    }

})();
